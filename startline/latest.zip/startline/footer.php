<footer>
	<hr>
	<div class="container">
		<p>&copy; 2016 Company, Inc.</p>
		<br>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
