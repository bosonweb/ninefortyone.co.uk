Directory for compiled Sass.
